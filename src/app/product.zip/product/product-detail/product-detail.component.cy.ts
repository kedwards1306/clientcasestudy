import { ExpenseDetailComponent } from './product-detail.component'

describe('ExpenseDetailComponent', () => {
  it('should mount', () => {
    cy.mount(ExpenseDetailComponent)
  })
})